package com.pvsearch;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class VaultScanner {
    /** Taranacak vault numaralari (/pv 1, /pv 2). Gerekirse buraya ekle. */
    public static final int[] VAULTS = {1, 2};

    public record Entry(int vault, int slot, ItemStack stack, ItemStack container, int containerSlot, String haystack) {}

    private enum State { IDLE, WAIT_OPEN, WAIT_CONTENT, WAIT_CLOSE }

    private static State state = State.IDLE;
    private static int index;
    private static int wait;
    private static boolean reopenSearch;
    private static List<Entry> building = new ArrayList<>();
    private static List<Entry> cache = List.of();

    private VaultScanner() {}

    public static boolean isRunning() { return state != State.IDLE; }

    public static List<Entry> getCache() { return cache; }

    public static void start(boolean reopen) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || isRunning()) return;
        reopenSearch = reopen;
        index = 0;
        building = new ArrayList<>();
        msg(mc, "Taranıyor...", Formatting.YELLOW);
        sendNext(mc);
    }

    private static void sendNext(MinecraftClient mc) {
        if (index >= VAULTS.length) {
            finish(mc);
            return;
        }
        mc.player.networkHandler.sendChatCommand("pv " + VAULTS[index]);
        state = State.WAIT_OPEN;
        wait = 0;
    }

    public static void tick(MinecraftClient mc) {
        if (state == State.IDLE) return;
        if (mc.player == null) {
            state = State.IDLE;
            return;
        }
        wait++;
        switch (state) {
            case WAIT_OPEN -> {
                if (mc.currentScreen instanceof GenericContainerScreen) {
                    state = State.WAIT_CONTENT;
                    wait = 0;
                } else if (wait > 100) {
                    abort(mc, "/pv " + VAULTS[index] + " açılmadı.");
                }
            }
            case WAIT_CONTENT -> {
                if (!(mc.currentScreen instanceof GenericContainerScreen screen)) {
                    abort(mc, "Sandık ekranı kapandı.");
                } else if (wait >= 10) {
                    scan(mc, screen, VAULTS[index]);
                    mc.player.closeHandledScreen();
                    state = State.WAIT_CLOSE;
                    wait = 0;
                }
            }
            case WAIT_CLOSE -> {
                if (wait >= 3 && mc.currentScreen == null) {
                    index++;
                    sendNext(mc);
                } else if (wait > 60) {
                    abort(mc, "Sandık kapanmadı.");
                }
            }
            default -> {}
        }
    }

    private static void scan(MinecraftClient mc, GenericContainerScreen screen, int vault) {
        GenericContainerScreenHandler handler = screen.getScreenHandler();
        int n = handler.getRows() * 9;
        for (int i = 0; i < n; i++) {
            ItemStack st = handler.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            building.add(make(mc, vault, i, st, null, -1));

            NbtCompound bet = st.getSubNbt("BlockEntityTag");
            if (bet != null && bet.contains("Items", NbtElement.LIST_TYPE)) {
                NbtList list = bet.getList("Items", NbtElement.COMPOUND_TYPE);
                for (int j = 0; j < list.size(); j++) {
                    NbtCompound c = list.getCompound(j);
                    ItemStack inner = ItemStack.fromNbt(c);
                    if (inner.isEmpty()) continue;
                    int slot = c.contains("Slot") ? (c.getByte("Slot") & 255) : j;
                    building.add(make(mc, vault, i, inner, st, slot));
                }
            }
        }
    }

    private static Entry make(MinecraftClient mc, int vault, int slot, ItemStack stack, ItemStack container, int cSlot) {
        StringBuilder sb = new StringBuilder();
        for (Text t : stack.getTooltip(mc.player, TooltipContext.Default.BASIC)) {
            sb.append(t.getString()).append(' ');
        }
        sb.append(Registries.ITEM.getId(stack.getItem()).getPath());
        return new Entry(vault, slot, stack, container, cSlot, normalize(sb.toString()));
    }

    private static void finish(MinecraftClient mc) {
        cache = building;
        state = State.IDLE;
        msg(mc, "Tarama bitti: " + cache.size() + " eşya kaydedildi.", Formatting.GREEN);
        if (reopenSearch) mc.setScreen(new SearchScreen());
    }

    private static void abort(MinecraftClient mc, String reason) {
        state = State.IDLE;
        if (mc.currentScreen instanceof GenericContainerScreen && mc.player != null) {
            mc.player.closeHandledScreen();
        }
        msg(mc, "Tarama durdu: " + reason, Formatting.RED);
    }

    private static void msg(MinecraftClient mc, String s, Formatting f) {
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("[PVSearch] " + s).formatted(f), false);
        }
    }

    public static List<Entry> search(String query) {
        String q = normalize(query == null ? "" : query).trim();
        if (q.isEmpty()) return cache;
        String[] tokens = q.split("\\s+");
        List<Entry> out = new ArrayList<>();
        for (Entry e : cache) {
            boolean all = true;
            for (String t : tokens) {
                if (!e.haystack().contains(t)) { all = false; break; }
            }
            if (all) out.add(e);
        }
        return out;
    }

    /** Turkce karakterleri ve aksanlari duzlestirir, kucuk harfe cevirir. */
    public static String normalize(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            switch (c) {
                case '\u0131', '\u0130', 'I' -> sb.append('i');
                case '\u015F', '\u015E' -> sb.append('s');
                case '\u011F', '\u011E' -> sb.append('g');
                case '\u00F6', '\u00D6' -> sb.append('o');
                case '\u00FC', '\u00DC' -> sb.append('u');
                case '\u00E7', '\u00C7' -> sb.append('c');
                default -> sb.append(c);
            }
        }
        String out = sb.toString().toLowerCase(Locale.ROOT);
        out = Normalizer.normalize(out, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return out;
    }
}
