package com.pvsearch;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

public class SearchScreen extends Screen {
    private static final int ROW = 20;
    private static final int TOP = 50;
    private static String lastQuery = "";

    private TextFieldWidget field;
    private List<VaultScanner.Entry> results = List.of();
    private int scroll = 0;

    public SearchScreen() {
        super(Text.literal("PV Search"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        field = new TextFieldWidget(this.textRenderer, cx - 150, 20, 230, 18, Text.literal("Ara"));
        field.setMaxLength(64);
        field.setText(lastQuery);
        field.setChangedListener(s -> {
            lastQuery = s;
            scroll = 0;
            refilter();
        });
        addDrawableChild(field);
        setInitialFocus(field);

        addDrawableChild(ButtonWidget.builder(Text.literal("Tara"), b -> {
            this.client.setScreen(null);
            VaultScanner.start(true);
        }).dimensions(cx + 90, 19, 60, 20).build());

        refilter();
    }

    private void refilter() {
        results = VaultScanner.search(field.getText());
    }

    private int visibleRows() {
        return Math.max(1, (this.height - TOP - 10) / ROW);
    }

    public static MutableText describe(VaultScanner.Entry e) {
        ItemStack s = e.stack();
        int row = e.slot() / 9 + 1;
        int col = e.slot() % 9 + 1;
        MutableText line = Text.literal("PV" + e.vault() + " [" + row + "," + col + "] ").formatted(Formatting.GRAY);
        line.append(s.getName().copy());
        line.append(Text.literal(" x" + s.getCount()).formatted(Formatting.YELLOW));
        if (e.container() != null) {
            line.append(Text.literal("  -> shulker: ").formatted(Formatting.DARK_AQUA));
            line.append(e.container().getName().copy().formatted(Formatting.AQUA));
            line.append(Text.literal(" #" + (e.containerSlot() + 1)).formatted(Formatting.DARK_AQUA));
        }
        return line;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 6, 0xFFFFFF);
        super.render(ctx, mouseX, mouseY, delta);

        if (VaultScanner.getCache().isEmpty()) {
            ctx.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal("Önce 'Tara' butonuna bas (/pv 1 ve /pv 2 taranır)."),
                    this.width / 2, TOP + 10, 0xFFAA00);
            return;
        }

        ctx.drawTextWithShadow(this.textRenderer,
                Text.literal(results.size() + " sonuç"), this.width / 2 - 150, 40, 0xAAAAAA);

        int left = this.width / 2 - 150;
        ItemStack hover = null;
        int end = Math.min(results.size(), scroll + visibleRows());
        for (int i = scroll; i < end; i++) {
            VaultScanner.Entry e = results.get(i);
            int y = TOP + (i - scroll) * ROW;
            ctx.drawItem(e.stack(), left, y);
            ctx.drawItemInSlot(this.textRenderer, e.stack(), left, y);
            ctx.drawTextWithShadow(this.textRenderer, describe(e), left + 22, y + 4, 0xFFFFFF);
            if (mouseX >= left && mouseX <= left + 16 && mouseY >= y && mouseY <= y + 16) {
                hover = e.stack();
            }
        }
        if (hover != null) {
            ctx.drawItemTooltip(this.textRenderer, hover, mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        int max = Math.max(0, results.size() - visibleRows());
        scroll = Math.max(0, Math.min(max, scroll - (int) Math.signum(amount)));
        return true;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
