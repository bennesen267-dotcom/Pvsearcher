package com.pvsearch;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class PvSearchClient implements ClientModInitializer {
    public static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pvsearch.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.pvsearch"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            VaultScanner.tick(client);
            while (openKey.wasPressed()) {
                if (client.currentScreen == null && client.player != null) {
                    client.setScreen(new SearchScreen());
                }
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("pvscan").executes(ctx -> {
                VaultScanner.start(false);
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("pvfind")
                    .then(ClientCommandManager.argument("query", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                String q = StringArgumentType.getString(ctx, "query");
                                List<VaultScanner.Entry> res = VaultScanner.search(q);
                                if (VaultScanner.getCache().isEmpty()) {
                                    ctx.getSource().sendFeedback(Text.literal("[PVSearch] Önce /pvscan yaz.").formatted(Formatting.RED));
                                    return 0;
                                }
                                ctx.getSource().sendFeedback(Text.literal("[PVSearch] " + res.size() + " sonuç").formatted(Formatting.GREEN));
                                int shown = 0;
                                for (VaultScanner.Entry e : res) {
                                    if (shown++ >= 15) break;
                                    ctx.getSource().sendFeedback(SearchScreen.describe(e));
                                }
                                return 1;
                            })));
        });
    }
}
