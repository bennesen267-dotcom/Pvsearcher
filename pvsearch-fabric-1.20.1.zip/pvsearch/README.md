# PV Search (Fabric 1.20.1, client only)

`/pv 1` ve `/pv 2` sandıklarını (ve içlerindeki shulker kutularını) tarar, eşya adı / lore / türüne göre arama yapar.
Türkçe karakter farkı yok sayılır ("yıkıcı" = "yikici" = "YIKICI").

## Kullanım
- **K** tuşu: arama ekranı. İlk seferde **Tara** butonuna bas.
- `/pvscan` : sandıkları tara
- `/pvfind <kelime>` : sohbette ara (ilk 15 sonuç)
- Hangi vault'lar taranacağını `VaultScanner.VAULTS` içinden değiştirebilirsin.

## Derleme
GitHub'a yükle, Actions sekmesinde `build` çalışır, jar `pvsearch-jar` artifact'ında çıkar.
Lokal: `gradle build` (Gradle 8.8, JDK 17) -> `build/libs/pvsearch-1.0.0.jar`
